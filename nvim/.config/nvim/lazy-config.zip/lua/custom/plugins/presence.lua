-- Discord status
return {
  'andweeb/presence.nvim',
  opts = {},
  event = 'VimEnter',
}
