-- Better tabs
return {
  'akinsho/bufferline.nvim',
  version = '*',
  event = 'VimEnter',
  dependencies = {
    'nvim-tree/nvim-web-devicons',
    'famiu/bufdelete.nvim',
  },
  opts = {
    options = {
      separator_style = 'slope',
      hover = {
        enabled = true,
        delay = 200,
        reveal = { 'close' },
      },
    },
  },

  -- NOTE: Buffer navigation config
  vim.keymap.set({ 'n', 'i', 'v', 'x' }, '<S-Left>', '<Cmd>BufferLineCyclePrev<CR>', { desc = 'Switch buffer left', silent = true, noremap = true }),
  vim.keymap.set({ 'n', 'i', 'v', 'x' }, '<S-Right>', '<Cmd>BufferLineCycleNext<CR>', { desc = 'Switch buffer right', silent = true, noremap = true }),
  vim.keymap.set({ 'n', 'i', 'v', 'x' }, '<C-S-Left>', '<Cmd>BufferLineMovePrev<CR>', { desc = 'Switch tab left', silent = true, noremap = true }),
  vim.keymap.set({ 'n', 'i', 'v', 'x' }, '<C-S-Right>', '<Cmd>BufferLineMoveNext<CR>', { desc = 'Move tab right', silent = true, noremap = true }),
}
