-- Autocompletion
return {
  'saghen/blink.cmp',
  event = 'VimEnter',
  version = '1.*',
  dependencies = {
    -- Snippet Engine
    {
      'L3MON4D3/LuaSnip',
      version = '2.*',
      build = (function()
        -- Build Step is needed for regex support in snippets.
        -- This step is not supported in many windows environments.
        -- Remove the below condition to re-enable on windows.
        if vim.fn.has 'win32' == 1 or vim.fn.executable 'make' == 0 then
          return
        end
        return 'make install_jsregexp'
      end)(),
      dependencies = {
        -- `friendly-snippets` contains a variety of premade snippets.
        --    See the README about individual language/framework/plugin snippets:
        --    https://github.com/rafamadriz/friendly-snippets
        {
          'rafamadriz/friendly-snippets',
          config = function()
            require('luasnip.loaders.from_vscode').lazy_load()
          end,
        },
        {},
      },
      opts = {},
    },
    'folke/lazydev.nvim',
    -- 'giuxtaposition/blink-cmp-copilot',
    'fang2hou/blink-copilot',
  },
  --- @module 'blink.cmp'
  --- @type blink.cmp.Config
  opts = {
    keymap = {
      -- 'default' (recommended) for mappings similar to built-in completions
      --   <c-y> to accept ([y]es) the completion.
      --    This will auto-import if your LSP supports it.
      --    This will expand snippets if the LSP sent a snippet.
      -- 'super-tab' for tab to accept
      -- 'enter' for enter to accept
      -- 'none' for no mappings
      --
      -- For an understanding of why the 'default' preset is recommended,
      -- you will need to read `:help ins-completion`
      --
      -- No, but seriously. Please read `:help ins-completion`, it is really good!
      --
      -- All presets have the following mappings:
      -- <tab>/<s-tab>: move to right/left of your snippet expansion
      -- <c-space>: Open menu or open docs if already open
      -- <c-n>/<c-p> or <up>/<down>: Select next/previous item
      -- <c-e>: Hide menu
      -- <c-k>: Toggle signature help
      --
      -- See :h blink-cmp-config-keymap for defining your own keymap
      preset = 'default',
      ['<A-Tab>'] = { 'accept' },

      -- Signature navigation
      -- Scrolling in completion menu and signature menu
      ['<Up>'] = {
        function(cmp)
          cmp.hide()
        end,
        'fallback',
      },

      ['<Down>'] = {
        function(cmp)
          cmp.hide()
        end,
        'fallback',
      },

      ['<C-Up>'] = {
        function(cmp)
          return cmp.select_prev { auto_insert = false }
        end,
        'scroll_signature_up',
        'fallback',
      },

      ['<C-Down>'] = {
        function(cmp)
          return cmp.select_next { auto_insert = false }
        end,
        'scroll_signature_down',
        'fallback',
      },
      -- For more advanced Luasnip keymaps (e.g. selecting choice nodes, expansion) see:
      --    https://github.com/L3MON4D3/LuaSnip?tab=readme-ov-file#keymaps
    },

    completion = {
      menu = {
        auto_show = false,
        auto_show_delay_ms = 500,
        border = vim.g.border,
      },

      -- La documentacion es un extra de el completion menu
      ghost_text = { enabled = true },
      documentation = {
        auto_show = false,
        auto_show_delay_ms = 500,
        window = {
          border = vim.g.border,
        },
      },
    },

    -- Shows a signature help window while you type arguments for a function
    signature = {
      enabled = true,
      window = {
        border = vim.g.border,
        show_documentation = true,
      },
    },

    sources = {
      default = { 'lsp', 'path', 'snippets', 'lazydev', 'buffer', 'copilot' },
      providers = {
        lazydev = { module = 'lazydev.integrations.blink', score_offset = 100 },
        -- WARNING: solo ocupar uno de los dos

        -- NOTE: Config for blink-cmp-copilit

        -- copilot = {
        --   module = 'blink-cmp-copilot',
        --   score_offset = 100,
        --   async = true,
        --   name = 'copilot',
        --   transform_items = function(_, items)
        --     local CompletionItemKind = require('blink.cmp.types').CompletionItemKind
        --     local kind_idx = #CompletionItemKind + 1
        --     CompletionItemKind[kind_idx] = 'Copilot'
        --     for _, item in ipairs(items) do
        --       item.kind = kind_idx
        --     end
        --     return items
        --   end,
        -- },
        --

        -- NOTE: Config for blink-copilot

        copilot = {
          name = 'copilot',
          module = 'blink-copilot',
          score_offset = 100,
          async = true,
        },
      },
    },

    snippets = { preset = 'luasnip' },

    -- Blink.cmp includes an optional, recommended rust fuzzy matcher,
    -- which automatically downloads a prebuilt binary when enabled.
    --
    -- By default, we use the Lua implementation instead, but you may enable
    -- the rust implementation via `'prefer_rust_with_warning'`
    --
    -- See :h blink-cmp-config-fuzzy for more information
    fuzzy = { implementation = 'lua' },

    appearance = {
      nerd_font_variant = 'normal',
      kind_icons = {
        Copilot = '',
        Text = '󰉿',
        Method = '󰊕',
        Function = '󰊕',
        Constructor = '󰒓',

        Field = '󰜢',
        Variable = '󰆦',
        Property = '󰖷',

        Class = '󱡠',
        Interface = '󱡠',
        Struct = '󱡠',
        Module = '󰅩',

        Unit = '󰪚',
        Value = '󰦨',
        Enum = '󰦨',
        EnumMember = '󰦨',

        Keyword = '󰻾',
        Constant = '󰏿',

        Snippet = '󱄽',
        Color = '󰏘',
        File = '󰈔',
        Reference = '󰬲',
        Folder = '󰉋',
        Event = '󱐋',
        Operator = '󰪚',
        TypeParameter = '󰬛',
      },
    },
  },
}
